03-05-2024
Winners and losers in U.S.–China trade disputes: A dynamic compositional analysis of foreign direct investment
Yoo Sun Jung & Yohan Park


To replicate the results successfully, please keep in mind the following things:

- Be sure to set the working directory to the master folder where all the replication files are placed.

- There are three sub-folders: "data",  "tables", and "figures".
"data" sub-folder includes three datasets for the analyses. 
 "tables" and "figures" sub-folders are present but currently devoid of any content. They are intended to keep the results generated through the execution of the do-files.

- There are three do-files:
1. [AN]01_main_figs : this is a do-file for replication of the figures in the main text.
2. [AN]02_main_tab :  this is a do-file for replication of the SUR regression tables in the Supplementary Information.
3. [AN]03_SI : this is a do-file for replication of the results in the Supplementary Information.